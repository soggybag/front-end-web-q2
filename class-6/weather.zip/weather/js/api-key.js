// Register with openweathermap and get your API key.
var apikey = "2854c5771899ff92cd962dd7ad58e7b0";